import os
import subprocess
import sys

def install_requirements():
    """Install required Python libraries from requirements.txt."""
    try:
        print("Installing required libraries...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", "requirements.txt"])
        print("All required libraries installed successfully.")
    except Exception as e:
        print(f"An error occurred while installing dependencies: {e}")

def main():
    """Main function to guide the user through the setup process."""
    print("Welcome to the Traffic Sign Classifiers setup script.")
    
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "--version"])
        print("pip is installed.")
    except Exception:
        print("pip is not installed. Please install pip and try again.")
        return

    install_requirements()

    print("Setup is complete. You can now run the test script:")
    print('Run the following command:')
    print('    python tests/testing.py')

if __name__ == "__main__":
    main()
